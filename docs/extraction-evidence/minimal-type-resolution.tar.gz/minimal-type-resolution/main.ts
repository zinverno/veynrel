import { Notice, Plugin } from "obsidian";

export default class ResolutionProbe extends Plugin {
  onload(): void {
    this.addCommand({
      id: "show-active-note",
      name: "Show active note",
      callback: () => {
        const file = this.app.workspace.getActiveFile();
        if (file) new Notice(file.basename);
      },
    });
  }
}
